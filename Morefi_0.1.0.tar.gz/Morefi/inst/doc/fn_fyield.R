## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Morefi)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_fyield <- function(i,bm,df){
                  Table_Y <- df
                  Table_Y <- dplyr::mutate(Table_Y,
                                           Yfit=   bm/Table_Y[,2],
                                           YIC_L=  bm/Table_Y[,3],
                                           YIC_U=  bm/Table_Y[,4],
                                           YIP_L=  bm/Table_Y[,5],
                                           YIP_U=  bm/Table_Y[,6]
                                           )
                  return(Table_Y)
            }   # End fn

## ----warning=FALSE, message=FALSE, eval = FALSE-------------------------------
#  FY <- fn_fyield(i,bm,df)

