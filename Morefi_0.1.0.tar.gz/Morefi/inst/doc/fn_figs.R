## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Morefi)

## -----------------------------------------------------------------------------
fn_figs <- function(datos, CIPI, i, etiquetas, modelos){
          Fig <- ggplot(CIPI,aes(x = CIPI[,1])) +
                 geom_ribbon(aes(x = CIPI[,1], ymin = CIPI[,3], ymax = CIPI[,4],
                                 fill = "aquamarine"), alpha = 1/50)    +
                 geom_ribbon(aes(x = CIPI[,1], ymin = CIPI[,5], ymax = CIPI[,6],
                                 fill = "grey", alpha = 1/50)) +
                 geom_line(aes(x= CIPI[,1], y = CIPI[,2])) +
                 geom_point(datos, mapping=aes(x= datos[,1], y = datos[,2],
                                 shape = factor(datos[,4]), stroke = 1,
                                 fill = datos[,4]), alpha = 1/10)+
                 labs(tag = letters[i],x= etiquetas[modelos[[i]][1]],
                                 y = etiquetas[modelos[[i]][2]])
          print(Fig)
}   # End fn_figs

## -----------------------------------------------------------------------------
set.seed(123)
rvar <- sample(-20:20, 100, replace=TRUE)
x <- sample(15:60,100,replace=T)
y <- (0.011*x^2.5)+rvar
n <- length(x)
Fleet <- as.factor(sample(1:2,100,replace = TRUE))

yc <- 0.011*x^2.5
datos <- data.frame(x1=x,y1=y,yc=yc,Fleet=Fleet)

# CI & PI

#SE <- sqrt(sum((y-yc)^2)/(100-2))
MSE <- sum((y-yc)^2)/(100-2)

xseq <- seq(15,60, by=2.5)
yseq <- 0.011*xseq^2.5

CP <- (1/n)+(((xseq-mean(xseq))^2)/sum((xseq-mean(xseq))^2))

ICl <- yseq -(1.96*(sqrt(MSE*CP)))
ICu <- yseq +(1.96*(sqrt(MSE*CP)))

IPl <- yseq -(1.96*(sqrt(MSE*(1+CP))))
IPu <- yseq +(1.96*(sqrt(MSE*(1+CP))))

df <- as.data.frame(cbind(xseq, yseq, ICl,ICu, IPl, IPu))
                    colnames(df) <- c("x1", "fit","IC_L","IC_U", "IP_L","IP_U")
                    df 
CIPI <- df

i <- 1

# To create the List etiquetas


lLT <- "LT (cm)"
lWT <- "WT (g)"

etiquetas <- list(lLT,lWT)

#To carry out each of the regressions, a list `modelos` is created to indicate 
#the variables that will be taken into account.

modelos <- list (LTvs.WT  =  c(1,2))

library(ggplot2)
#theme_papers <- readRDS("theme_papers.rds")
FY <- fn_figs(datos, CIPI, i, etiquetas, modelos)


