## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Morefi)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_R2RV <- function(eq,a=1){
      w <- eq$rweights   # w a vector of weights values
      yc <- eq$fitted.values # yc a vector of predicted values
      ywea <-  (1/sum(w)) * sum(w*yc) # a value of the Weighted Estimate Average
      y1 <- eq$model[,1]
      SSEw <- sum(w*(yc-ywea)^2)
      SSRw <- sum(w*(y1-yc)^2)
      a <- a
      R2wa <- SSEw/(SSEw+a*SSRw)
      R2wa_adj <- 1-(1-R2wa)*((length(y1)-1)/summary(eq)$df[2])
      R2was <- c(R2wa,R2wa_adj)
      print(R2was)
    }

## ----warning=FALSE, message=FALSE, eval = FALSE-------------------------------
#  R2RV <- fn_R2RV(eq,a)

