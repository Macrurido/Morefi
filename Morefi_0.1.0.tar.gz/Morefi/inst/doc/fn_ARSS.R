## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Morefi)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_ARSS <- function(List_TCCT, i,  alfa= 0.05){
  T  <- list()
  for (i in 1:length(List_TCCT)){
  
  T1 <- List_TCCT[[i]]
  lvar <- names(List_TCCT[i])

  T1[1,1] <- paste0(substr(lvar,1,2)," vs. ",
                    substr(lvar,3,nchar(lvar)))
  # RSSs sum of the RSS of each regression fitted
  T1[4,3] <- round(sum(as.numeric(T1[1,3]),
                       as.numeric(T1[2,3])),2)

  # DF Sum GL1 + GL2
  T1[4,4] <- sum(as.numeric(T1[1,4]),as.numeric(T1[2,4]))

  # F calculated (Fc)
  T1[1,5] <- round(abs((as.numeric(T1[3,3])-as.numeric(T1[4,3]))/
                         as.numeric(T1[4,3])),4)

  # F table (critical value)
  T1[1,6] <- round(qf(alfa, as.numeric(T1[3,4]),
                      as.numeric(T1[4,4]),
                      lower.tail= FALSE),4)

  # p-value for two tails
  P_value <- pf(as.numeric(T1[1,6]),
                as.numeric(T1[4,4]),
                as.numeric(T1[3,4]),
                lower.tail=FALSE)

  T1[1,7] <- if(P_value>1-alfa){
    "p>0.95"
  } else {
    format(P_value, format= "e", digits = 4)
  } # End if

  # Decision criteria
  T1[1,8] <-  if(P_value>alfa){
    "NS"
  } else {
    "*"
  } # End if
  T[[i]] <- as.data.frame(T1)
  } # End for
  return(T)
}  # End function

## ----warning=FALSE, message=FALSE---------------------------------------------
Table_CC <- data.frame(matrix(NA,nrow=4,ncol=8))
Table_CC[1,1] <- "Lt-WT" 
Table_CC[,2] <- c("Females","Males","Total","Joined")
colnames(Table_CC) <- c("Model","Category","RSS","DF","ARSS","F-table","p-value","Criteria")

Table_CC[1,3] <- 1557970.877
Table_CC[1,4] <-  93 
Table_CC[2,3] <- 1188689.721
Table_CC[2,4] <-  116 
Table_CC[3,3] <- 2045176.876
Table_CC[3,4] <-  211 


List_ARSS <- list(LTWT=Table_CC)

i <- 1

ARSS <- fn_ARSS(List_ARSS, i,  alfa= 0.05)
ARSS

