## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Morefi)

## ----warning=FALSE, message=FALSE---------------------------------------------

fn_intervals <- function(eq,xseq){
                    new.data <- as.data.frame(xseq)
                    str(predFit(eq, new.data, se.fit = TRUE))
                    CI95 <- predFit(eq, newdata = new.data,
                                    interval = "confidence",level=0.95)
                    PI95 <- predFit(eq, newdata = new.data,
                                    interval = "prediction",level=0.95)

                    df <- as.data.frame(cbind(xseq,CI95,PI95[,-1]))
                    colnames(df) <- c("x1", "fit","IC_L","IC_U", "IP_L","IP_U")
                    df
                    }


## ----warning=FALSE, message=FALSE, eval = FALSE-------------------------------
#  IC <- fn_intervals(eq,xseq)

