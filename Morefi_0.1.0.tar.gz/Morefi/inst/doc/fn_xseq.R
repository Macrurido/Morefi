## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Morefi)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_xseq <- function(modelos,List_x_seq, i) {
  if (modelos[[i]][1]== 1) {
    xseq <- List_x_seq[[1]]
  } else {
      if (modelos[[i]][1]== 2) {
             xseq <- List_x_seq[[2]]
      } else {
            if (modelos[[i]][1]== 4) {
                  xseq <- List_x_seq[[3]]
            } else {
                  xseq <- List_x_seq[[4]]
      }  # End if                  
    }  # End if
  }  # End if
  xseq <- data.frame(x1=xseq)
} # End fn

## ----warning=FALSE, message=FALSE, eval = FALSE-------------------------------
#  xseq <- fn_xseq(modelos,List_x_seq, i)

